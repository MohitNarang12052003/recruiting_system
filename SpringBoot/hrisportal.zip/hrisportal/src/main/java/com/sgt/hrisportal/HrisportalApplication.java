package com.sgt.hrisportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrisportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrisportalApplication.class, args);
	}

}
