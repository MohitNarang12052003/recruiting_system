package com.sgt.hrisportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrisportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
